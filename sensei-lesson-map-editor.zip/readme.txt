=== Sensei Lesson Map Editor ===
Contributors: ottenharoldpatrick-gif, chatgpt
Requires at least: 6.4
Tested up to: 6.6
Requires PHP: 8.1
Stable tag: 0.3.0
License: GPLv2 or later

Visuele leskaart + admin editor voor Sensei LMS: vrije kaart / kolommen, drag & drop, mediabibliotheek-achtergrond, tegels met labels en voltooid-icoon.

== Description ==
- Per cursus een visuele kaart.
- Vrije kaart (default) of 3 kolommen op desktop, 1 kolom mobiel.
- Admin editor: inline preview, drag & drop posities (alleen visueel).
- Achtergrond per cursus via mediabibliotheek.
- Tegelgrootte: s/m/l/custom; 3-tekens label; ✅/❌ status.
- Shortcode: [sensei_lesson_map course_id="123"]

== Changelog ==
= 0.3.0 =
* Definitieve opslaan via AJAX met nonce/cap.
* Echte Sensei-lessen ipv dummy.
* Mediabibliotheek achtergronden.
* Tegelgrootte + labels + z-index.
* Frontend hover met titel + voortgang.
