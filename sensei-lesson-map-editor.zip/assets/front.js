// Frontend heeft geen JS nodig voor drag; hover is CSS-based.
// Dit bestand blijft klaar voor toekomstige uitbreidingen.
